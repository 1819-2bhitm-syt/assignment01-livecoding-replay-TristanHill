# 1819_2bhitm_syt_assignment01a
Wiederholung des livecoding-projekts während des Unterrichts 
